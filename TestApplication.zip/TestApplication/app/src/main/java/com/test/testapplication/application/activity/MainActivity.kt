package com.test.testapplication.application.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.test.testapplication.R
import kotlinx.android.synthetic.main.activity_main.*
import org.kodein.di.Kodein
import org.kodein.di.KodeinAware
import org.kodein.di.android.closestKodein

class MainActivity : AppCompatActivity(), KodeinAware {

    override val kodein: Kodein by closestKodein()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //initToolbar()
        //(baseContext as AppCompatActivity).supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }


}
